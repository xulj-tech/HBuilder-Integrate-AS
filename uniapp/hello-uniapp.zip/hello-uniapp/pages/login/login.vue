<template>
	<view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		onLoad() {
			console.log("--onLoad--")
		},
		onShow() {
			console.log("--onShow--")
		},
		onReady() {
			
		},
		onHide() {
			
		},
		onPullDownRefresh() {
			
		}
		
		
	}
</script>

<style>

</style>
