<template>
	<view class="content">
		<view class="view_search"> 
		<uni-combox style="width: 250rpx; font-size: 15rpx;" label="状态" :candidates="candidates" placeholder="请选择" v-model="status"></uni-combox>
		<text class="tip_date">日期</text> 
		<text class="text_date" @click="selectDate(true)">{{startDate}}</text>
		<text>-</text> 
		<text class="text_date" @click="selectDate(false)">{{endDate}}</text>
		<uni-calendar ref="calendar" :insert="false" @confirm="confirm"></uni-calendar>
		</view>
		<view style="width: 100%; height: 3rpx; background-color: #999999;"></view>
		<view>
			<uni-table border stripe emptyText="暂无更多数据" >
			    <!-- 表头行 -->
			    <uni-tr>
			        <uni-th width="10rpx" align="center">序号</uni-th>
			        <uni-th width="10rpx" align="center">标题</uni-th>
			        <uni-th width="10rpx" align="center">状态</uni-th>
					<uni-th width="10rpx" align="center">创建人</uni-th>
					<uni-th width="10rpx" align="center">创建时间</uni-th>
					<uni-th width="10rpx" align="center">截止</uni-th>
			    </uni-tr>
			    <!-- 表格数据行 -->
			    <uni-tr v-for="item in orders">
			        <uni-td align="center" v-for="value in item" :key="item.id">{{value}}</uni-td>
			    </uni-tr>
			</uni-table>
		</view>
		<view>
			<view class="active" v-for="item in tabArray" :key="item.id">{{item.title}}</view>
		</view>
		<button class="btn" @click="showToast(title)">原生toast</button>
		<button class="btn"  @click="sendMessage(jsData)">sendMessage</button>
		<button class="btn"  @click="gotoNativePage()">gotoNativePage</button>
	</view>
</template>

<script>
	var appModule = uni.requireNativePlugin("AppModule");
	export default {
		data() {
			return {
				title: 'vue.js',
				jsData: 'data from vue...',
				candidates: ['新建', '分派中', '下发', '执行中', '退回', '取消', '完成','无法完成'],
				isStart : true,
				status: '',
				startDate:'',
				endDate:'',
				orders:[
					{
						'id':'1',
						'title':'下水道堵塞',
						'status':'下发',
						'creater':'leo',
						'createTime':'06-10',
						'endTime':'06-30',
					},
					{
						'id':'2',
						'title':'路灯闪',
						'status':'进行中',
						'creater':'rose',
						'createTime':'06-20',
						'endTime':'06-30',
					},
					{
						'id':'3',
						'title':'漏水',
						'status':'进行中',
						'creater':'sim',
						'createTime':'06-20',
						'endTime':'06-30',
					}
				],
				tabArray:[
					{
						'id':'1',
						'title':'详情'
					},
					{
						'id':'2',
						'title':'描述'
					},
					{
						'id':'3',
						'title':'通信'
					},
					{
						'id':'4',
						'title':'日志'
					}
					]
			}
			
		},
		onLoad() {
			 plus.global.addEventListener("MyEvent",function(result){
			                uni.showToast({
			                    title: 'Hello MyEvent '
			                });
			            })
		},
		methods: {
				showToast(msg){
			        appModule.showToast(msg);
			    },
			    sendMessage(data){
			        appModule.sendMsg(data,ret=>{
			            appModule.showToast(ret);
			                    })
			        },
			    gotoNativePage(){
			            appModule.gotoNativePage();
			        },
				confirm(res){
					if(this.isStart){
						this.startDate = res.fulldate ;
					}else{
						this.endDate = res.fulldate ;
					}
				},
				selectDate(type){
					this.isStart = type;
					this.$refs.calendar.open();
				}
				
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		onReachBottom() {
			console.log("页面触底了");
		}
		
	}
</script>

<style>
	.content {
		display: flex;
	    flex-direction: column;
	}
    .view_search {
		display: flex;
		padding: 15rpx;
		height: 60rpx;
		align-items: center;
	}
	/deep/ .uni-combox__input {
	    font-size: 15px;
	}
	.tip_date {
		width: 70rpx;
		margin-left: 20rpx;
	}
	.text_date {
		width: 160rpx;
		height: 46rpx;
		text-align: center;
		font-size: 16rpx;
		margin-left: 10rpx;
		margin-right: 10rpx;
		border-style: solid;
		border-color: #808080;
		border-width: 1rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.input_date {
		border-color:#007AFF;
		border-style: solid;
	}
</style>
